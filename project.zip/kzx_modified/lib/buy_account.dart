import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

// ─────────────────────────────────────────────
// GANTI dengan API KEY Cashi.id kamu
const String _cashiApiKey = 'CASHI-5R3UOV84SVQ';
const String _cashiBaseUrl = 'https://cashi.id/api';
// ─────────────────────────────────────────────

class _Package {
  final String role;
  final String duration;
  final int price;
  final String label;
  const _Package({required this.role, required this.duration, required this.price, required this.label});
}

const List<_Package> _packages = [
  _Package(role: 'Member',   duration: '1 Bulan',   price: 5000,  label: 'Member · 1 Bulan'),
  _Package(role: 'Member',   duration: 'Permanent',  price: 10000, label: 'Member · Permanent'),
  _Package(role: 'VIP',      duration: '1 Bulan',   price: 15000, label: 'VIP · 1 Bulan'),
  _Package(role: 'VIP',      duration: 'Permanent',  price: 30000, label: 'VIP · Permanent'),
  _Package(role: 'Reseller', duration: '1 Bulan',   price: 40000, label: 'Reseller · 1 Bulan'),
  _Package(role: 'Reseller', duration: 'Permanent',  price: 55000, label: 'Reseller · Permanent'),
  _Package(role: 'Owner',    duration: 'Permanent',  price: 70000, label: 'Owner · Permanent'),
];

Color _roleColor(String role) {
  switch (role) {
    case 'VIP':      return const Color(0xFFFFD700);
    case 'Reseller': return const Color(0xFF00E5FF);
    case 'Owner':    return const Color(0xFFFF4081);
    default:         return const Color(0xFF64FFDA);
  }
}

IconData _roleIcon(String role) {
  switch (role) {
    case 'VIP':      return Icons.star_rounded;
    case 'Reseller': return Icons.store_rounded;
    case 'Owner':    return Icons.shield_rounded;
    default:         return Icons.person_rounded;
  }
}

// ─────────────────────────────────────────────
class BuyAccountPage extends StatelessWidget {
  const BuyAccountPage({super.key});

  @override
  Widget build(BuildContext context) {
    final roles = ['Member', 'VIP', 'Reseller', 'Owner'];
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Color(0xFF64FFDA)),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Buy Access',
          style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 18, color: Colors.white, letterSpacing: 2),
        ),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: Colors.white10),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 18),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: LinearGradient(
                colors: [Colors.purpleAccent.withOpacity(0.18), Colors.black],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              border: Border.all(color: Colors.purpleAccent.withOpacity(0.35)),
            ),
            child: Row(
              children: [
                const Icon(Icons.qr_code_2_rounded, color: Colors.purpleAccent, size: 34),
                const SizedBox(width: 14),
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('APPS TEXAS PRICE LIST',
                      style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, color: Colors.white, fontSize: 13, letterSpacing: 1.5)),
                    const SizedBox(height: 4),
                    const Text('Pembayaran otomatis via QRIS · Cashi.id',
                      style: TextStyle(fontFamily: 'ShareTechMono', color: Colors.white38, fontSize: 11)),
                  ],
                )),
              ],
            ),
          ),
          const SizedBox(height: 24),
          ...roles.map((role) {
            final pkgs = _packages.where((p) => p.role == role).toList();
            return _RoleCard(role: role, packages: pkgs);
          }),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
class _RoleCard extends StatelessWidget {
  final String role;
  final List<_Package> packages;
  const _RoleCard({required this.role, required this.packages});

  @override
  Widget build(BuildContext context) {
    final color = _roleColor(role);
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.4), width: 1.2),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
            ),
            child: Row(
              children: [
                Icon(_roleIcon(role), color: color, size: 20),
                const SizedBox(width: 10),
                Text(role.toUpperCase(),
                  style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, color: color, fontSize: 14, letterSpacing: 2)),
              ],
            ),
          ),
          ...packages.map((pkg) => _PackageRow(pkg: pkg, roleColor: color)),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
class _PackageRow extends StatelessWidget {
  final _Package pkg;
  final Color roleColor;
  const _PackageRow({required this.pkg, required this.roleColor});

  String _fmt(int price) => 'Rp ${price >= 1000 ? "${(price / 1000).toStringAsFixed(0)}K" : "$price"}';

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13),
      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.05)))),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: roleColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: roleColor.withOpacity(0.3)),
            ),
            child: Text(pkg.duration,
              style: TextStyle(fontFamily: 'ShareTechMono', color: roleColor, fontSize: 11, fontWeight: FontWeight.bold)),
          ),
          const Spacer(),
          Text(_fmt(pkg.price),
            style: const TextStyle(fontFamily: 'Orbitron', color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold)),
          const SizedBox(width: 14),
          SizedBox(
            height: 34,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: roleColor,
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(horizontal: 16),
                elevation: 0,
              ),
              onPressed: () => showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                backgroundColor: Colors.transparent,
                builder: (_) => _PaymentSheet(pkg: pkg, roleColor: roleColor),
              ),
              child: const Text('BUY',
                style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1.5)),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────
// PAYMENT SHEET — pakai endpoint Cashi.id yang bener
// POST /create-order  →  { success, qrUrl, checkout_url, order_id }
// GET  /check-status/:orderId  →  { status: 'SETTLED'|'PENDING' }
// ─────────────────────────────────────────────
class _PaymentSheet extends StatefulWidget {
  final _Package pkg;
  final Color roleColor;
  const _PaymentSheet({required this.pkg, required this.roleColor});

  @override
  State<_PaymentSheet> createState() => _PaymentSheetState();
}

class _PaymentSheetState extends State<_PaymentSheet> {
  String _state = 'init'; // init | loading | waiting | success | failed
  String? _qrBase64;      // data:image/png;base64,...
  String? _checkoutUrl;
  String? _invoiceId;
  String? _errorMsg;
  int _countdown = 300;
  Timer? _pollTimer;
  Timer? _cdTimer;

  @override
  void dispose() {
    _pollTimer?.cancel();
    _cdTimer?.cancel();
    super.dispose();
  }

  // ── Buat transaksi ke Cashi.id ──
  Future<void> _createTransaction() async {
    setState(() { _state = 'loading'; _errorMsg = null; });
    try {
      final orderId = 'TEXAS-${DateTime.now().millisecondsSinceEpoch}';

      final res = await http.post(
        Uri.parse('$_cashiBaseUrl/create-order'),
        headers: {
          'x-api-key': _cashiApiKey,
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'amount': widget.pkg.price,
          'order_id': orderId,
        }),
      ).timeout(const Duration(seconds: 30));

      final data = jsonDecode(res.body);

      if ((data['success'] == true || res.statusCode == 200) && data['qrUrl'] != null) {
        setState(() {
          _invoiceId = orderId;
          _qrBase64  = data['qrUrl']?.toString();
          _checkoutUrl = data['checkout_url']?.toString();
          _state = 'waiting';
          _countdown = 300;
        });
        _startCountdown();
        _startPolling();
      } else {
        setState(() {
          _state = 'failed';
          _errorMsg = data['message']?.toString() ?? 'Gagal buat transaksi (${res.statusCode})';
        });
      }
    } catch (e) {
      setState(() { _state = 'failed'; _errorMsg = e.toString(); });
    }
  }

  // ── Polling status setiap 5 detik ──
  void _startPolling() {
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      if (_invoiceId == null) return;
      try {
        final res = await http.get(
          Uri.parse('$_cashiBaseUrl/check-status/$_invoiceId'),
          headers: {'x-api-key': _cashiApiKey},
        ).timeout(const Duration(seconds: 10));

        final data = jsonDecode(res.body);
        final status = data['status']?.toString().toUpperCase();

        if (status == 'SETTLED') {
          _pollTimer?.cancel(); _cdTimer?.cancel();
          if (mounted) setState(() => _state = 'success');
        } else if (status == 'EXPIRED' || status == 'FAILED' || status == 'CANCEL') {
          _pollTimer?.cancel(); _cdTimer?.cancel();
          if (mounted) setState(() { _state = 'failed'; _errorMsg = 'Transaksi expired/gagal.'; });
        }
      } catch (_) {}
    });
  }

  // ── Countdown 5 menit ──
  void _startCountdown() {
    _cdTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      if (_countdown <= 0) {
        _cdTimer?.cancel(); _pollTimer?.cancel();
        if (_state == 'waiting') setState(() { _state = 'failed'; _errorMsg = 'Waktu pembayaran habis.'; });
      } else {
        setState(() => _countdown--);
      }
    });
  }

  String _fmtCd(int s) => '${(s ~/ 60).toString().padLeft(2,'0')}:${(s % 60).toString().padLeft(2,'0')}';
  String _fmtPrice(int p) => 'Rp ${p.toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (_) => '.')}';

  @override
  Widget build(BuildContext context) {
    final color = widget.roleColor;
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF111111),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 16),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
          Text(widget.pkg.label,
            style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, color: color, fontSize: 15, letterSpacing: 1.5)),
          const SizedBox(height: 4),
          Text(_fmtPrice(widget.pkg.price),
            style: const TextStyle(fontFamily: 'ShareTechMono', color: Colors.white70, fontSize: 13)),
          const SizedBox(height: 20),
          AnimatedSwitcher(duration: const Duration(milliseconds: 300), child: _buildContent(color)),
        ],
      ),
    );
  }

  Widget _buildContent(Color color) {
    switch (_state) {
      // ── Loading ──
      case 'loading':
        return Padding(key: const ValueKey('l'), padding: const EdgeInsets.symmetric(vertical: 40),
          child: Column(children: [
            CircularProgressIndicator(color: color, strokeWidth: 2),
            const SizedBox(height: 16),
            const Text('Membuat transaksi...', style: TextStyle(fontFamily: 'ShareTechMono', color: Colors.white54)),
          ]));

      // ── Menunggu pembayaran ──
      case 'waiting':
        return Column(key: const ValueKey('w'), children: [
          // QR image — Cashi.id kirim base64 PNG
          if (_qrBase64 != null) ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
              child: Builder(builder: (_) {
                try {
                  // Strip prefix "data:image/png;base64,"
                  final raw = _qrBase64!.contains(',') ? _qrBase64!.split(',').last : _qrBase64!;
                  return Image.memory(base64Decode(raw), width: 200, height: 200);
                } catch (_) {
                  return const SizedBox(width: 200, height: 200,
                    child: Center(child: Text('Gagal load QR', style: TextStyle(color: Colors.red))));
                }
              }),
            ),
          ] else ...[
            const SizedBox(height: 20),
            const Text('QR tidak tersedia, gunakan link bayar di bawah',
              textAlign: TextAlign.center,
              style: TextStyle(fontFamily: 'ShareTechMono', color: Colors.white54, fontSize: 11)),
          ],

          const SizedBox(height: 14),
          // Countdown
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.timer_outlined, color: Colors.white38, size: 16),
            const SizedBox(width: 6),
            Text('Bayar dalam ${_fmtCd(_countdown)}',
              style: TextStyle(fontFamily: 'ShareTechMono',
                color: _countdown < 60 ? Colors.redAccent : Colors.white54, fontSize: 13)),
          ]),
          const SizedBox(height: 6),
          const Text('Scan QRIS dengan e-wallet / mobile banking manapun',
            textAlign: TextAlign.center,
            style: TextStyle(fontFamily: 'ShareTechMono', color: Colors.white38, fontSize: 11)),

          const SizedBox(height: 14),

          // Link checkout jika ada
          if (_checkoutUrl != null)
            GestureDetector(
              onTap: () {
                Clipboard.setData(ClipboardData(text: _checkoutUrl!));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Link disalin'), duration: Duration(seconds: 2)));
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.white12)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  const Text('Atau bayar via link', style: TextStyle(fontFamily: 'ShareTechMono', color: Colors.white54, fontSize: 11)),
                  const SizedBox(width: 8),
                  const Icon(Icons.copy_rounded, color: Colors.white30, size: 13),
                ]),
              ),
            ),

          // Order ID
          if (_invoiceId != null) ...[
            const SizedBox(height: 10),
            GestureDetector(
              onTap: () {
                Clipboard.setData(ClipboardData(text: _invoiceId!));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Order ID disalin'), duration: Duration(seconds: 2)));
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.white12)),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text('ID: $_invoiceId',
                    style: const TextStyle(fontFamily: 'ShareTechMono', color: Colors.white54, fontSize: 11)),
                  const SizedBox(width: 8),
                  const Icon(Icons.copy_rounded, color: Colors.white30, size: 13),
                ]),
              ),
            ),
          ],

          const SizedBox(height: 16),
          TextButton(onPressed: () => Navigator.pop(context),
            child: const Text('BATAL', style: TextStyle(fontFamily: 'ShareTechMono', color: Colors.white38, letterSpacing: 1.5))),
        ]);

      // ── Sukses ──
      case 'success':
        return Padding(key: const ValueKey('s'), padding: const EdgeInsets.symmetric(vertical: 30),
          child: Column(children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(color: Colors.green.withOpacity(0.12), shape: BoxShape.circle,
                border: Border.all(color: Colors.green.withOpacity(0.4), width: 2)),
              child: const Icon(Icons.check_rounded, color: Colors.green, size: 48),
            ),
            const SizedBox(height: 20),
            const Text('PEMBAYARAN BERHASIL!',
              style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, color: Colors.green, fontSize: 14, letterSpacing: 2)),
            const SizedBox(height: 10),
            const Text('Akun kamu akan segera diupgrade.\nHubungi admin jika ada masalah.',
              textAlign: TextAlign.center,
              style: TextStyle(fontFamily: 'ShareTechMono', color: Colors.white54, fontSize: 12, height: 1.6)),
            const SizedBox(height: 24),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12)),
              onPressed: () => Navigator.pop(context),
              child: const Text('SELESAI', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1.5)),
            ),
          ]));

      // ── Gagal ──
      case 'failed':
        return Padding(key: const ValueKey('f'), padding: const EdgeInsets.symmetric(vertical: 24),
          child: Column(children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), shape: BoxShape.circle,
                border: Border.all(color: Colors.red.withOpacity(0.4), width: 2)),
              child: const Icon(Icons.error_outline_rounded, color: Colors.red, size: 40),
            ),
            const SizedBox(height: 16),
            const Text('TRANSAKSI GAGAL',
              style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, color: Colors.redAccent, fontSize: 13, letterSpacing: 2)),
            if (_errorMsg != null) ...[
              const SizedBox(height: 8),
              Text(_errorMsg!, textAlign: TextAlign.center,
                style: const TextStyle(fontFamily: 'ShareTechMono', color: Colors.white38, fontSize: 11)),
            ],
            const SizedBox(height: 20),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              OutlinedButton(
                style: OutlinedButton.styleFrom(foregroundColor: Colors.white54, side: const BorderSide(color: Colors.white24),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10)),
                onPressed: () => Navigator.pop(context),
                child: const Text('TUTUP', style: TextStyle(fontFamily: 'Orbitron', fontSize: 11, letterSpacing: 1.5)),
              ),
              const SizedBox(width: 12),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: widget.roleColor, foregroundColor: Colors.black,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10)),
                onPressed: _createTransaction,
                child: const Text('COBA LAGI', style: TextStyle(fontFamily: 'Orbitron', fontSize: 11, fontWeight: FontWeight.bold)),
              ),
            ]),
          ]));

      // ── Init (konfirmasi) ──
      default:
        return Padding(key: const ValueKey('i'), padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(children: [
            const Text('Kamu akan membayar via QRIS.\nPastikan saldo e-wallet/rekening cukup.',
              textAlign: TextAlign.center,
              style: TextStyle(fontFamily: 'ShareTechMono', color: Colors.white54, fontSize: 12, height: 1.6)),
            const SizedBox(height: 8),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: const [
              Icon(Icons.access_time_rounded, color: Colors.white30, size: 14),
              SizedBox(width: 5),
              Text('QRIS aktif 5 menit', style: TextStyle(fontFamily: 'ShareTechMono', color: Colors.white30, fontSize: 11)),
              SizedBox(width: 16),
              Icon(Icons.verified_rounded, color: Colors.white30, size: 14),
              SizedBox(width: 5),
              Text('Auto verifikasi', style: TextStyle(fontFamily: 'ShareTechMono', color: Colors.white30, fontSize: 11)),
            ]),
            const SizedBox(height: 22),
            SizedBox(
              width: double.infinity, height: 48,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: color, foregroundColor: Colors.black,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  elevation: 0,
                ),
                icon: const Icon(Icons.qr_code_2_rounded, size: 20),
                label: const Text('BAYAR SEKARANG',
                  style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 1.5)),
                onPressed: _createTransaction,
              ),
            ),
            const SizedBox(height: 10),
            TextButton(onPressed: () => Navigator.pop(context),
              child: const Text('BATAL', style: TextStyle(fontFamily: 'ShareTechMono', color: Colors.white30, letterSpacing: 1.5))),
          ]));
    }
  }
}
