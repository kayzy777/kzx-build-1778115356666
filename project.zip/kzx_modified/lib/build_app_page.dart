import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

class BuildAppPage extends StatefulWidget {
  const BuildAppPage({super.key});
  @override
  State<BuildAppPage> createState() => _BuildAppPageState();
}

class _BuildAppPageState extends State<BuildAppPage> with TickerProviderStateMixin {
  // ── Theme ──
  static const Color primary = Color(0xFF00E5CC);
  static const Color bg = Color(0xFF060E17);
  static const Color card = Color(0xFF0D1F2D);
  static const Color card2 = Color(0xFF111E2B);

  // ── API ──
  static const String _apiKey = 'AkatSuki';
  static const String _buildUrl = 'https://web2app.joomods.web.id/api/xbuild';
  static const String _resultUrl = 'https://web2app.joomods.web.id/api/xresult.js';

  // ── State ──
  final TextEditingController _urlCtrl = TextEditingController();
  bool _isBuilding = false;
  bool _isDone = false;
  bool _isError = false;
  String _status = '';
  String _downloadLink = '';
  String _buildId = '';
  int _progress = 0;
  Timer? _pollTimer;
  List<String> _logs = [];

  // ── Animation ──
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.4, end: 1.0).animate(CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _urlCtrl.dispose();
    _pollTimer?.cancel();
    _pulseCtrl.dispose();
    super.dispose();
  }

  // ── Start Build ──
  Future<void> _startBuild() async {
    final zipUrl = _urlCtrl.text.trim();
    if (zipUrl.isEmpty) {
      _showSnack('Masukkan URL ZIP Flutter dulu');
      return;
    }
    if (!zipUrl.startsWith('http')) {
      _showSnack('URL harus dimulai dengan http/https');
      return;
    }

    setState(() {
      _isBuilding = true;
      _isDone = false;
      _isError = false;
      _status = 'Mengirim project ke server build...';
      _downloadLink = '';
      _buildId = '';
      _progress = 5;
      _logs = ['[${_time()}] Memulai build...', '[${_time()}] Mengirim URL ke server...'];
    });

    try {
      http.Response res;
      Map<String, dynamic> data = {};

      // Format 1: POST JSON
      _addLog('[${_time()}] Mencoba POST JSON...');
      res = await http.post(
        Uri.parse(_buildUrl),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'X-Api-Key': _apiKey,
        },
        body: jsonEncode({'apikey': _apiKey, 'url': zipUrl, 'key': _apiKey}),
      ).timeout(const Duration(seconds: 30));
      _addLog('[${_time()}] POST JSON: ${res.statusCode} - ${res.body.length > 150 ? res.body.substring(0, 150) : res.body}');

      if (res.statusCode == 200) {
        try { data = jsonDecode(res.body); } catch (_) {}
      }

      // Format 2: POST multipart/form-data
      if (res.statusCode != 200 || data['success'] == false) {
        _addLog('[${_time()}] Mencoba POST multipart...');
        final request = http.MultipartRequest('POST', Uri.parse(_buildUrl));
        request.fields['apikey'] = _apiKey;
        request.fields['key'] = _apiKey;
        request.fields['url'] = zipUrl;
        final mRes = await request.send().timeout(const Duration(seconds: 30));
        res = await http.Response.fromStream(mRes);
        _addLog('[${_time()}] Multipart: ${res.statusCode} - ${res.body.length > 150 ? res.body.substring(0, 150) : res.body}');
        if (res.statusCode == 200) {
          try { data = jsonDecode(res.body); } catch (_) {}
        }
      }

      // Format 3: GET dengan query param
      if (res.statusCode != 200 || data['success'] == false) {
        _addLog('[${_time()}] Mencoba GET...');
        res = await http.get(
          Uri.parse('$_buildUrl?apikey=$_apiKey&key=$_apiKey&url=${Uri.encodeComponent(zipUrl)}'),
          headers: {'Accept': 'application/json'},
        ).timeout(const Duration(seconds: 30));
        _addLog('[${_time()}] GET: ${res.statusCode} - ${res.body.length > 150 ? res.body.substring(0, 150) : res.body}');
        if (res.statusCode == 200) {
          try { data = jsonDecode(res.body); } catch (_) {}
        }
      }

      // Format 4: POST form-urlencoded
      if (res.statusCode != 200 || data['success'] == false) {
        _addLog('[${_time()}] Mencoba POST form...');
        res = await http.post(
          Uri.parse(_buildUrl),
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          body: 'apikey=$_apiKey&key=$_apiKey&url=${Uri.encodeComponent(zipUrl)}',
        ).timeout(const Duration(seconds: 30));
        _addLog('[${_time()}] POST form: ${res.statusCode} - ${res.body.length > 150 ? res.body.substring(0, 150) : res.body}');
        if (res.statusCode == 200) {
          try { data = jsonDecode(res.body); } catch (_) {}
        }
      }

      if (res.statusCode == 200 && data['success'] != false) {
        _buildId = (data['id'] ?? data['build_id'] ?? data['task_id'] ?? data['token'] ?? '').toString();
        _addLog('[${_time()}] ✅ Build dimulai! ID: $_buildId');
        setState(() { _status = 'Build sedang berjalan...'; _progress = 15; });
        _startPolling();
      } else {
        final msg = data['message'] ?? data['error'] ?? data['msg'] ?? 'Gagal (${res.statusCode})';
        _setError(msg.toString());
      }
    } catch (e) {
      _setError('Koneksi gagal: $e');
    }
  }

  // ── Polling result ──
  void _startPolling() {
    int attempt = 0;
    _pollTimer = Timer.periodic(const Duration(seconds: 5), (timer) async {
      attempt++;
      _addLog('[${_time()}] Mengecek status... (${attempt}x)');

      try {
        final uri = _buildId.isNotEmpty
            ? Uri.parse('$_resultUrl?apikey=$_apiKey&id=$_buildId')
            : Uri.parse('$_resultUrl?apikey=$_apiKey');

        final res = await http.get(uri).timeout(const Duration(seconds: 15));
        _addLog('[${_time()}] Poll ${attempt}: ${res.statusCode} - ${res.body.length > 100 ? res.body.substring(0, 100) : res.body}');

        Map<String, dynamic> data = {};
        try { data = jsonDecode(res.body); } catch (_) {
          // Kalau bukan JSON, cek apakah ada URL download di body
          if (res.body.contains('http') && res.body.contains('.apk')) {
            final match = RegExp(r'https?://[^\s"<>]+\.apk').firstMatch(res.body);
            if (match != null) { timer.cancel(); _setDone(match.group(0)!); return; }
          }
          return;
        }

        final status = (data['status'] ?? '').toString().toLowerCase();
        final done = data['done'] == true || status == 'done' || status == 'success' ||
            status == 'completed' || status == 'finish' || status == 'selesai';
        final failed = data['failed'] == true || status == 'failed' || status == 'error';

        if (done) {
          timer.cancel();
          final link = data['url'] ?? data['download'] ?? data['apk'] ?? data['link'] ?? data['result'] ?? data['file'] ?? '';
          _setDone(link.toString());
        } else if (failed) {
          timer.cancel();
          final msg = data['message'] ?? data['error'] ?? 'Build gagal';
          _setError(msg.toString());
        } else {
          final p = data['progress'] ?? data['percent'];
          if (p != null) setState(() => _progress = (p as num).toInt().clamp(15, 90));
          else setState(() => _progress = (_progress + 3).clamp(15, 90));
          final msg = data['message'] ?? data['status_text'] ?? data['step'] ?? 'Building...';
          setState(() => _status = msg.toString());
        }

        if (attempt >= 120) { timer.cancel(); _setError('Build timeout (10 menit).'); }
      } catch (e) {
        _addLog('[${_time()}] Poll error: $e');
      }
    });
  }

  void _setDone(String link) {
    setState(() {
      _isBuilding = false;
      _isDone = true;
      _isError = false;
      _downloadLink = link;
      _progress = 100;
      _status = 'Build selesai! APK siap download.';
    });
    _addLog('[${_time()}] ✅ Build sukses!');
    _addLog('[${_time()}] Download: $link');
  }

  void _setError(String msg) {
    setState(() {
      _isBuilding = false;
      _isDone = false;
      _isError = true;
      _status = msg;
      _progress = 0;
    });
    _addLog('[${_time()}] ❌ Error: $msg');
  }

  void _addLog(String msg) {
    if (mounted) setState(() { _logs.add(msg); if (_logs.length > 50) _logs.removeAt(0); });
  }

  String _time() {
    final n = DateTime.now();
    return '${n.hour.toString().padLeft(2, '0')}:${n.minute.toString().padLeft(2, '0')}:${n.second.toString().padLeft(2, '0')}';
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: card2, duration: const Duration(seconds: 2)),
    );
  }

  void _reset() {
    _pollTimer?.cancel();
    setState(() {
      _isBuilding = false;
      _isDone = false;
      _isError = false;
      _status = '';
      _downloadLink = '';
      _buildId = '';
      _progress = 0;
      _logs = [];
    });
  }

  // ════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(colors: [Color(0xFF060E17), Color(0xFF0A1929)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                  child: Column(
                    children: [
                      _buildUrlCard(),
                      const SizedBox(height: 16),
                      if (_isBuilding || _isDone || _isError) ...[
                        _buildStatusCard(),
                        const SizedBox(height: 16),
                      ],
                      if (_isDone && _downloadLink.isNotEmpty) ...[
                        _buildDownloadCard(),
                        const SizedBox(height: 16),
                      ],
                      if (_logs.isNotEmpty) _buildLogsCard(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Header ──
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40, height: 40,
              decoration: BoxDecoration(color: primary.withOpacity(0.15), borderRadius: BorderRadius.circular(12), border: Border.all(color: primary.withOpacity(0.4))),
              child: const Icon(Icons.arrow_back_ios_new_rounded, color: primary, size: 18),
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('BUILD APP', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', letterSpacing: 2)),
              Text('Flutter APK Builder', style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 11, fontFamily: 'ShareTechMono')),
            ],
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: primary.withOpacity(0.1), borderRadius: BorderRadius.circular(16), border: Border.all(color: primary.withOpacity(0.3))),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Container(width: 6, height: 6, decoration: const BoxDecoration(color: primary, shape: BoxShape.circle)),
              const SizedBox(width: 5),
              const Text('ONLINE', style: TextStyle(color: primary, fontSize: 10, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
            ]),
          ),
        ],
      ),
    );
  }

  // ── URL Input Card ──
  Widget _buildUrlCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: primary.withOpacity(0.2)),
        boxShadow: [BoxShadow(color: primary.withOpacity(0.06), blurRadius: 20)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(shape: BoxShape.circle, color: primary.withOpacity(0.15), border: Border.all(color: primary.withOpacity(0.4))),
              child: const Icon(Icons.link_rounded, color: primary, size: 20),
            ),
            const SizedBox(width: 12),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('URL ZIP Flutter', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15, fontFamily: 'Orbitron')),
                Text('Paste link zip project kamu', style: TextStyle(color: Colors.white38, fontSize: 11, fontFamily: 'ShareTechMono')),
              ],
            ),
          ]),
          const SizedBox(height: 16),
          Container(
            decoration: BoxDecoration(color: card2, borderRadius: BorderRadius.circular(16)),
            child: TextField(
              controller: _urlCtrl,
              style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'ShareTechMono'),
              cursorColor: primary,
              maxLines: 3,
              minLines: 1,
              decoration: InputDecoration(
                hintText: 'https://example.com/project.zip',
                hintStyle: TextStyle(color: Colors.white.withOpacity(0.25), fontFamily: 'ShareTechMono', fontSize: 13),
                prefixIcon: const Padding(padding: EdgeInsets.only(left: 12, right: 8), child: Icon(Icons.folder_zip_outlined, color: Colors.white38, size: 20)),
                prefixIconConstraints: const BoxConstraints(minWidth: 40),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.paste_rounded, color: Colors.white38, size: 18),
                  onPressed: () async {
                    final data = await Clipboard.getData('text/plain');
                    if (data?.text != null) _urlCtrl.text = data!.text!;
                  },
                ),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: primary, width: 1.5)),
                contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Tips
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: primary.withOpacity(0.05), borderRadius: BorderRadius.circular(12), border: Border.all(color: primary.withOpacity(0.15))),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.info_outline_rounded, color: primary, size: 14),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Upload ZIP project Flutter ke Google Drive / Dropbox / hosting, lalu paste link direct download-nya di sini.',
                    style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11, fontFamily: 'ShareTechMono', height: 1.5),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // Buttons
          Row(
            children: [
              if (_isBuilding || _isDone || _isError) ...[
                Expanded(
                  flex: 1,
                  child: GestureDetector(
                    onTap: _isBuilding ? null : _reset,
                    child: Container(
                      height: 52,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.07),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: Colors.white12),
                      ),
                      child: const Center(child: Icon(Icons.refresh_rounded, color: Colors.white54, size: 22)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
              ],
              Expanded(
                flex: 4,
                child: GestureDetector(
                  onTap: _isBuilding ? null : _startBuild,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    height: 52,
                    decoration: BoxDecoration(
                      gradient: _isBuilding
                          ? LinearGradient(colors: [Colors.grey.shade700, Colors.grey.shade800])
                          : const LinearGradient(colors: [primary, Color(0xFF00BFA5)], begin: Alignment.centerLeft, end: Alignment.centerRight),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: _isBuilding ? [] : [BoxShadow(color: primary.withOpacity(0.35), blurRadius: 16, spreadRadius: 1)],
                    ),
                    child: Center(
                      child: _isBuilding
                          ? Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                              AnimatedBuilder(
                                animation: _pulseAnim,
                                builder: (_, __) => Opacity(opacity: _pulseAnim.value, child: const Icon(Icons.build_circle_rounded, color: Colors.white, size: 20)),
                              ),
                              const SizedBox(width: 10),
                              const Text('BUILDING...', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1)),
                            ])
                          : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                              Icon(Icons.rocket_launch_rounded, color: Colors.black87, size: 20),
                              SizedBox(width: 10),
                              Text('MULAI BUILD', style: TextStyle(color: Colors.black87, fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1)),
                            ]),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Status Card ──
  Widget _buildStatusCard() {
    final color = _isError ? Colors.redAccent : _isDone ? const Color(0xFF00C853) : primary;
    final icon = _isError ? Icons.error_outline_rounded : _isDone ? Icons.check_circle_rounded : Icons.pending_rounded;

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: color.withOpacity(0.3)),
        boxShadow: [BoxShadow(color: color.withOpacity(0.08), blurRadius: 20)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(0.15), border: Border.all(color: color.withOpacity(0.4))),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_isError ? 'Build Gagal' : _isDone ? 'Build Selesai ✅' : 'Sedang Build...', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15, fontFamily: 'Orbitron')),
                  const SizedBox(height: 2),
                  Text(_status, style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11, fontFamily: 'ShareTechMono'), maxLines: 2, overflow: TextOverflow.ellipsis),
                ],
              ),
            ),
          ]),

          if (_isBuilding) ...[
            const SizedBox(height: 20),
            // Progress bar
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: LinearProgressIndicator(
                value: _progress / 100,
                backgroundColor: Colors.white10,
                valueColor: AlwaysStoppedAnimation<Color>(color),
                minHeight: 8,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Progress', style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 10, fontFamily: 'ShareTechMono')),
                Text('$_progress%', style: TextStyle(color: color, fontSize: 11, fontFamily: 'ShareTechMono', fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 16),
            // Build ID
            if (_buildId.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(color: card2, borderRadius: BorderRadius.circular(10)),
                child: Row(children: [
                  Icon(Icons.tag_rounded, color: Colors.white.withOpacity(0.3), size: 14),
                  const SizedBox(width: 6),
                  Text('Build ID: $_buildId', style: const TextStyle(color: Colors.white38, fontSize: 11, fontFamily: 'ShareTechMono')),
                ]),
              ),
          ],
        ],
      ),
    );
  }

  // ── Download Card ──
  Widget _buildDownloadCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Color(0xFF00C853).withOpacity(0.4)),
        boxShadow: [BoxShadow(color: Color(0xFF00C853).withOpacity(0.1), blurRadius: 20)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Container(
              width: 40, height: 40,
              decoration: BoxDecoration(shape: BoxShape.circle, color: Color(0xFF00C853).withOpacity(0.15), border: Border.all(color: Color(0xFF00C853).withOpacity(0.4))),
              child: const Icon(Icons.download_rounded, color: Color(0xFF00C853), size: 20),
            ),
            const SizedBox(width: 12),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('APK Siap!', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15, fontFamily: 'Orbitron')),
                Text('Tap untuk download APK', style: TextStyle(color: Colors.white38, fontSize: 11, fontFamily: 'ShareTechMono')),
              ],
            ),
          ]),
          const SizedBox(height: 14),
          // Link box
          GestureDetector(
            onTap: () => Clipboard.setData(ClipboardData(text: _downloadLink)).then((_) => _showSnack('Link disalin!')),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: card2, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.white10)),
              child: Row(children: [
                const Icon(Icons.link_rounded, color: Colors.white38, size: 16),
                const SizedBox(width: 8),
                Expanded(child: Text(_downloadLink, style: const TextStyle(color: Colors.white60, fontSize: 11, fontFamily: 'ShareTechMono'), maxLines: 2, overflow: TextOverflow.ellipsis)),
                const Icon(Icons.copy_rounded, color: Colors.white38, size: 16),
              ]),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.download_rounded, size: 20),
              label: const Text('DOWNLOAD APK', style: TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, letterSpacing: 1)),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF00C853),
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
              onPressed: () => Clipboard.setData(ClipboardData(text: _downloadLink)).then((_) => _showSnack('Link APK disalin! Buka di browser.')),
            ),
          ),
        ],
      ),
    );
  }

  // ── Build Logs ──
  Widget _buildLogsCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            const Icon(Icons.terminal_rounded, color: Colors.white38, size: 16),
            const SizedBox(width: 8),
            const Text('BUILD LOG', style: TextStyle(color: Colors.white54, fontSize: 12, fontFamily: 'Orbitron', letterSpacing: 1)),
            const Spacer(),
            GestureDetector(
              onTap: () => Clipboard.setData(ClipboardData(text: _logs.join('\n'))).then((_) => _showSnack('Log disalin!')),
              child: const Icon(Icons.copy_rounded, color: Colors.white24, size: 16),
            ),
          ]),
          const SizedBox(height: 10),
          Container(
            height: 160,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: card2, borderRadius: BorderRadius.circular(12)),
            child: ListView.builder(
              reverse: true,
              itemCount: _logs.length,
              itemBuilder: (_, i) {
                final log = _logs[_logs.length - 1 - i];
                final isError = log.contains('❌');
                final isSuccess = log.contains('✅');
                return Padding(
                  padding: const EdgeInsets.only(bottom: 3),
                  child: Text(
                    log,
                    style: TextStyle(
                      color: isError ? Colors.redAccent : isSuccess ? const Color(0xFF00C853) : Colors.white38,
                      fontSize: 10,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
