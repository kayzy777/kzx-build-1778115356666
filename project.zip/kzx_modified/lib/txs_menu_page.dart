import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'services/api_config_service.dart';

import 'custom_bug.dart';
import 'bug_group.dart';
import 'home_page.dart';
import 'tes_func_page.dart';
import 'notification_page.dart';

class TxsMenuPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String sessionKey;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;

  const TxsMenuPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.sessionKey,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
  });

  @override
  State<TxsMenuPage> createState() => _TxsMenuPageState();
}

class _TxsMenuPageState extends State<TxsMenuPage> with TickerProviderStateMixin {
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;
  final PageController _pageController = PageController(viewportFraction: 0.88);
  int _currentPage = 0;
  int _unreadNotifCount = 0;

  static const Color teal      = Color(0xFF00C896);
  static const Color tealLight = Color(0xFF00E5A8);
  static const Color bgDark    = Color(0xFF061610);
  static const Color bgMid     = Color(0xFF0A1F18);

  final List<Map<String, dynamic>> _menus = [
    {
      "title": "TEXAS BUG",
      "icon": FontAwesomeIcons.whatsapp,
      "description": "Bug tanpa custom",
      "note": "Gunakan langsung tanpa custom delay dan loops",
      "badge": "RECOMMENDED",
      "badgeColor": Color(0xFFFF7B2E),
      "iconColor": Color(0xFF00C896),
      "cardColor1": Color(0xFF0D3D2A),
      "cardColor2": Color(0xFF072214),
      "features": ["Mudah digunakan", "Function terbaru", "All work gacor"],
      "buttonText": "START MODULE",
      "buttonColor1": Color(0xFF009E76),
      "buttonColor2": Color(0xFF00C896),
      "page": "lx",
    },
    {
      "title": "CUSTOM BUG",
      "icon": FontAwesomeIcons.squareWhatsapp,
      "description": "Menu custom bug",
      "note": "Buat menu bug, delay pengiriman dan loops sesuka kamu",
      "badge": "CUSTOM",
      "badgeColor": Color(0xFF4F6EFF),
      "iconColor": Color(0xFF4F6EFF),
      "cardColor1": Color(0xFF0D1540),
      "cardColor2": Color(0xFF060D2A),
      "features": ["Pengaturan mudah", "Support multi bug", "Bebas spam"],
      "buttonText": "START MODULE",
      "buttonColor1": Color(0xFF2E3FCC),
      "buttonColor2": Color(0xFF4F6EFF),
      "page": "custom",
    },
    {
      "title": "GROUP BUG",
      "icon": FontAwesomeIcons.users,
      "description": "Menu group bug",
      "note": "Kirim bug ke group WhatsApp dengan mudah dan cepat",
      "badge": "GROUP",
      "badgeColor": Color(0xFFAA88FF),
      "iconColor": Color(0xFFAA88FF),
      "cardColor1": Color(0xFF1A0D3D),
      "cardColor2": Color(0xFF100720),
      "features": ["Support group", "Auto join", "Multi target"],
      "buttonText": "START MODULE",
      "buttonColor1": Color(0xFF7744CC),
      "buttonColor2": Color(0xFFAA88FF),
      "page": "group",
    },
    {
      "title": "TES FUNCTION",
      "icon": Icons.code_rounded,
      "description": "Kirim function custom ke target",
      "note": "Kirim function custom dengan delay & loops ke nomor WhatsApp target",
      "badge": "BETA",
      "badgeColor": Color(0xFF00E5A8),
      "iconColor": Color(0xFF00C896),
      "cardColor1": Color(0xFF0A2E22),
      "cardColor2": Color(0xFF051810),
      "features": ["Custom payload", "Delay & loops", "Pick file .js"],
      "buttonText": "START MODULE",
      "buttonColor1": Color(0xFF009E76),
      "buttonColor2": Color(0xFF00C896),
      "page": "tesfunc",
    },
    {
      "title": "CONTACT ADMIN",
      "icon": FontAwesomeIcons.headset,
      "description": "Hubungi admin jika ada kendala",
      "note": "Bantuan dan dukungan teknis tersedia untuk kamu",
      "badge": "SUPPORT",
      "badgeColor": Color(0xFFFF6B6B),
      "iconColor": Color(0xFFFF6B6B),
      "cardColor1": Color(0xFF3D0D0D),
      "cardColor2": Color(0xFF220707),
      "features": ["Ada bug", "Func tidak work", "Fitur tidak berfungsi"],
      "buttonText": "CONTACT NOW",
      "buttonColor1": Color(0xFFCC3333),
      "buttonColor2": Color(0xFFFF4444),
      "page": "contact",
      "url": "https://t.me/maklolacurrr",
    },
  ];

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);
    _glowAnimation = CurvedAnimation(parent: _glowController, curve: Curves.easeInOut);
    _pageController.addListener(() {
      int page = _pageController.page?.round() ?? 0;
      if (page != _currentPage) setState(() => _currentPage = page);
    });
    _fetchUnreadCount();
  }

  Future<void> _fetchUnreadCount() async {
    try {
      final baseUrl = await ApiConfig.baseUrl;
      final res = await http.get(
        Uri.parse('$baseUrl/api/user/getNotifications?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] == true && mounted) {
        final notifs = data['notifications'] as List? ?? [];
        setState(() {
          _unreadNotifCount = notifs.where((n) => n['isRead'] != true).length;
        });
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _glowController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _launchUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Tidak dapat membuka link'), backgroundColor: Colors.red),
        );
      }
    }
  }

  void _navigateToPage(String pageType, {String? url}) {
    if (pageType == "contact" && url != null) { _launchUrl(url); return; }
    switch (pageType) {
      case "custom":
        Navigator.push(context, MaterialPageRoute(builder: (_) => CustomAttackPage(
          username: widget.username, password: widget.password,
          listPayload: widget.listPayload, role: widget.role,
          expiredDate: widget.expiredDate, sessionKey: widget.sessionKey,
        )));
        break;
      case "group":
        Navigator.push(context, MaterialPageRoute(builder: (_) => GroupBugPage(
          username: widget.username, password: widget.password,
          role: widget.role, expiredDate: widget.expiredDate, sessionKey: widget.sessionKey,
        )));
        break;
      case "lx":
        Navigator.push(context, MaterialPageRoute(builder: (_) => AttackPage(
          username: widget.username, password: widget.password,
          listBug: widget.listBug, role: widget.role,
          expiredDate: widget.expiredDate, sessionKey: widget.sessionKey,
        )));
        break;
      case "tesfunc":
        Navigator.push(context, MaterialPageRoute(builder: (_) => TesFuncPage(
          sessionKey: widget.sessionKey,
          username: widget.username,
          role: widget.role,
        )));
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgMid, bgDark],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Column(
            children: [
              _buildHeroHeader(),
              const SizedBox(height: 8),
              SizedBox(height: 370, child: _buildCardSlider()),
              _buildDots(),
              _buildFooterInfo(),
              const SizedBox(height: 12),
            ],
          ),
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.35),
        border: Border(bottom: BorderSide(color: teal.withOpacity(0.15))),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: const Icon(Icons.arrow_back, color: teal, size: 24),
          ),
          Column(
            children: [
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF00C896), Color(0xFF007A58)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [BoxShadow(color: teal.withOpacity(0.5), blurRadius: 10)],
                ),
                child: const Center(child: FaIcon(FontAwesomeIcons.whatsapp, color: Colors.white, size: 20)),
              ),
              const SizedBox(height: 2),
              const Text("TEXAS", style: TextStyle(color: teal, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 2)),
            ],
          ),
          Row(
            children: [
              const Icon(Icons.music_note, color: Colors.white54, size: 22),
              const SizedBox(width: 14),
              Stack(clipBehavior: Clip.none, children: [
                GestureDetector(
                  onTap: () async {
                    await Navigator.push(context, MaterialPageRoute(
                      builder: (_) => NotificationPage(sessionKey: widget.sessionKey),
                    ));
                    _fetchUnreadCount();
                  },
                  child: const Icon(Icons.notifications, color: Colors.white54, size: 22),
                ),
                if (_unreadNotifCount > 0)
                  Positioned(
                    top: -4, right: -4,
                    child: Container(
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        color: Colors.red, shape: BoxShape.circle,
                        border: Border.all(color: bgDark, width: 1.2),
                      ),
                      child: _unreadNotifCount <= 9
                          ? Text('$_unreadNotifCount',
                              style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900))
                          : const Text('9+',
                              style: TextStyle(color: Colors.white, fontSize: 7, fontWeight: FontWeight.w900)),
                    ),
                  )
                else
                  Positioned(
                    top: -2, right: -2,
                    child: Container(
                      width: 7, height: 7,
                      decoration: BoxDecoration(color: Colors.red, shape: BoxShape.circle,
                          border: Border.all(color: bgDark, width: 1)),
                    ),
                  ),
              ]),
              const SizedBox(width: 14),
              const Icon(Icons.logout, color: Colors.white54, size: 22),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHeroHeader() {
    return Padding(
      padding: const EdgeInsets.only(top: 12, bottom: 4),
      child: Column(children: [
        AnimatedBuilder(
          animation: _glowAnimation,
          builder: (_, __) => Container(
            width: 52, height: 52,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF25D366), Color(0xFF128C7E)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(
                color: const Color(0xFF25D366).withOpacity(0.35 + _glowAnimation.value * 0.3),
                blurRadius: 12 + _glowAnimation.value * 8, spreadRadius: 1,
              )],
            ),
            child: const Center(child: FaIcon(FontAwesomeIcons.whatsapp, color: Colors.white, size: 26)),
          ),
        ),
        const SizedBox(height: 8),
        ShaderMask(
          shaderCallback: (b) => const LinearGradient(colors: [tealLight, teal, Color(0xFF00FFBE)]).createShader(b),
          child: const Text("TEXAS MENU", style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900, fontFamily: "Orbitron", letterSpacing: 4)),
        ),
        const SizedBox(height: 4),
        Text("Pilih menu yang tersedia bosque!", style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 12)),
        const SizedBox(height: 8),
        Container(
          width: 40, height: 2,
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Colors.transparent, teal, Colors.transparent]),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ]),
    );
  }

  Widget _buildCardSlider() {
    return PageView.builder(
      controller: _pageController,
      itemCount: _menus.length,
      physics: const BouncingScrollPhysics(),
      itemBuilder: (context, index) {
        return AnimatedBuilder(
          animation: _pageController,
          builder: (_, child) {
            double scale = 1.0;
            if (_pageController.position.haveDimensions) {
              double page = _pageController.page ?? index.toDouble();
              scale = (1 - (page - index).abs() * 0.06).clamp(0.94, 1.0);
            }
            return Transform.scale(scale: scale, child: child);
          },
          child: _buildCard(_menus[index]),
        );
      },
    );
  }

  Widget _buildCard(Map<String, dynamic> menu) {
    final Color badgeColor = menu["badgeColor"] as Color;
    final Color iconColor  = menu["iconColor"]  as Color;
    final Color c1         = menu["cardColor1"] as Color;
    final Color c2         = menu["cardColor2"] as Color;
    final Color btn1       = menu["buttonColor1"] as Color;
    final Color btn2       = menu["buttonColor2"] as Color;
    final bool isContact   = menu["page"] == "contact";

    final Widget cardContent = SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Icon + Badge
            Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: iconColor.withOpacity(0.15),
                    shape: BoxShape.circle,
                    border: Border.all(color: iconColor.withOpacity(0.3)),
                  ),
                  child: Center(
                    child: menu["page"] == "tesfunc"
                        ? Icon(menu["icon"] as IconData, color: iconColor, size: 26)
                        : FaIcon(menu["icon"] as IconData, color: iconColor, size: 26),
                  ),
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    color: badgeColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: badgeColor),
                  ),
                  child: Text(
                    menu["badge"] as String,
                    style: TextStyle(
                      color: badgeColor,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 8),

            // Title
            Text(
              menu["title"] as String,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.w900,
                fontFamily: "Orbitron",
                letterSpacing: 1.5,
              ),
            ),

            const SizedBox(height: 3),

            // Desc
            Text(
              menu["description"] as String,
              style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 13),
            ),

            const SizedBox(height: 10),

            // Divider
            Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [iconColor.withOpacity(0.4), Colors.transparent],
                ),
              ),
            ),

            const SizedBox(height: 10),

            // Note - plain text like photo
            Text(
              menu["note"] as String,
              style: TextStyle(
                color: Colors.white.withOpacity(0.75),
                fontSize: 13,
              ),
            ),

            const SizedBox(height: 8),

            // Features
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: (menu["features"] as List<String>).map((f) {
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: iconColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: iconColor.withOpacity(0.3)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.check_circle_outline, color: iconColor, size: 12),
                      const SizedBox(width: 5),
                      Text(
                        f,
                        style: TextStyle(
                          color: iconColor.withOpacity(0.9),
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),

            const SizedBox(height: 10),

            // START MODULE BUTTON
            SizedBox(
              width: double.infinity,
              height: 52,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [btn1, btn2]),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: btn2.withOpacity(0.4),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: ElevatedButton(
                  onPressed: () => _navigateToPage(menu["page"], url: menu["url"]),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        isContact ? Icons.send : Icons.play_arrow_rounded,
                        color: Colors.white,
                        size: 22,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        menu["buttonText"] as String,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 15,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                          fontFamily: "Orbitron",
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );

    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (_, __) {
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [c1.withOpacity(0.85), c2.withOpacity(0.9)],
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: iconColor.withOpacity(0.22 + _glowAnimation.value * 0.2),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: iconColor.withOpacity(_glowAnimation.value * 0.1),
                blurRadius: 20,
                spreadRadius: 2,
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.4),
                blurRadius: 15,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: cardContent,
        );
      },
    );
  }

  Widget _buildDots() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(_menus.length, (i) {
          final bool active = i == _currentPage;
          return AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            margin: const EdgeInsets.symmetric(horizontal: 4),
            width: active ? 26 : 8,
            height: 8,
            decoration: BoxDecoration(
              color: active ? teal : teal.withOpacity(0.3),
              borderRadius: BorderRadius.circular(4),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildFooterInfo() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: teal.withOpacity(0.15)),
      ),
      child: Row(children: [
        Container(
          width: 30, height: 30,
          decoration: BoxDecoration(
            color: teal.withOpacity(0.12), shape: BoxShape.circle,
            border: Border.all(color: teal.withOpacity(0.3)),
          ),
          child: const Center(child: Icon(Icons.info_outline, color: teal, size: 16)),
        ),
        const SizedBox(width: 10),
        Expanded(child: Text(
          "Semua menu telah diuji coba dan tanpa gimmick real work 100%",
          style: TextStyle(color: Colors.white.withOpacity(0.55), fontSize: 11),
        )),
      ]),
    );
  }
}
