import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'dart:ui';
import 'services/api_config_service.dart';

class GroupBugPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;

  const GroupBugPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<GroupBugPage> createState() => _GroupBugPageState();
}

class _GroupBugPageState extends State<GroupBugPage> with TickerProviderStateMixin {
  final linkGroupController = TextEditingController();

  String? _baseUrl;
  bool _isLoadingConfig = true;

  // Animation controllers
  late AnimationController _buttonController;
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late AnimationController _glowController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _glowAnimation;

  // Video controllers
  late VideoPlayerController _videoController;
  bool _videoInitialized = false;
  bool _videoError = false;

  // State variables
  bool _isSending = false;

  // Group list dari sender pribadi
  List<Map<String, dynamic>> _myGroups = [];
  String? _selectedGroupJid;
  String? _selectedGroupName;

  // Blue color palette
  final Color brightBlue = const Color(0xFF9E9E9E);
  final Color deepBlue = const Color(0xFF0D47A1);
  final Color lightBlue = const Color(0xFFBDBDBD);
  final Color darkBlue = const Color(0xFF0A2F4A);
  final Color neonBlue = const Color(0xFF00B0FF);

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _loadServerUrl();
    _initializeVideoController();
    _startAnimations();
  }

  Future<void> _loadServerUrl() async {
    try {
      final url = await ApiConfig.baseUrl;
      setState(() {
        _baseUrl = url;
        _isLoadingConfig = false;
      });
    } catch (e) {
      setState(() {
        _isLoadingConfig = false;
      });
    }
  }

  void _initializeAnimations() {
    _buttonController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _buttonController, curve: Curves.easeInOut),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));
    _glowAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  void _startAnimations() {
    _fadeController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      _slideController.forward();
    });
  }

  void _initializeVideoController() {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _videoInitialized = true;
            });
            _videoController.setLooping(true);
            _videoController.play();
            _videoController.setVolume(25);
          }
        }).catchError((error) {
          if (mounted) {
            setState(() {
              _videoError = true;
            });
          }
        });
    } catch (e) {
      if (mounted) {
        setState(() {
          _videoError = true;
        });
      }
    }
  }

  bool _isValidGroupLink(String input) {
    final regex = RegExp(r'https://chat\.whatsapp\.com/[a-zA-Z0-9]{22}');
    return regex.hasMatch(input);
  }

  Color _getRoleColor() {
    switch (widget.role.toLowerCase()) {
      case 'owner':
        return Colors.red;
      case 'vip':
        return Colors.amber;
      case 'reseller':
        return brightBlue;
      default:
        return brightBlue;
    }
  }

  Future<void> _fetchMyGroups() async {
    try {
      final baseUrl = await ApiConfig.baseUrl;
      final res = await http.get(
        Uri.parse('$baseUrl/api/whatsapp/getMyGroups?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        setState(() {
          _myGroups = List<Map<String, dynamic>>.from(data['groups'] ?? []);
        });
      }
    } catch (_) {}
  }

  Future<bool> _checkPrivateSender() async {
    try {
      final baseUrl = await ApiConfig.baseUrl;
      final res = await http.get(
        Uri.parse('$baseUrl/api/whatsapp/mySender?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      final List private = data['connections']?['private'] ?? [];
      return private.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  void _showGroupSelectionSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setModal) => Container(
          height: MediaQuery.of(context).size.height * 0.65,
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.97),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            border: Border.all(color: brightBlue.withOpacity(0.2)),
          ),
          child: Column(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 10),
                width: 40, height: 4,
                decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                child: Row(
                  children: [
                    Container(
                      width: 36, height: 36,
                      decoration: BoxDecoration(color: brightBlue, shape: BoxShape.circle),
                      child: const Icon(Icons.group, color: Colors.white, size: 18),
                    ),
                    const SizedBox(width: 12),
                    const Text("PILIH GROUP", style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontWeight: FontWeight.w900, fontSize: 14, letterSpacing: 1)),
                    const Spacer(),
                    GestureDetector(
                      onTap: () => Navigator.pop(ctx),
                      child: const Icon(Icons.close, color: Colors.white54, size: 22),
                    ),
                  ],
                ),
              ),
              const Divider(color: Colors.white12, height: 1),
              if (_myGroups.isEmpty)
                Expanded(
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.group_off, color: Colors.white24, size: 48),
                        const SizedBox(height: 12),
                        Text("Tidak ada group ditemukan", style: TextStyle(color: Colors.white38, fontSize: 13)),
                      ],
                    ),
                  ),
                )
              else
                Expanded(
                  child: ListView.builder(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    itemCount: _myGroups.length,
                    itemBuilder: (_, i) {
                      final group = _myGroups[i];
                      final jid = group['jid'] as String;
                      final name = group['name'] as String;
                      final count = group['participants'] ?? 0;
                      final isSelected = _selectedGroupJid == jid;

                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            _selectedGroupJid = jid;
                            _selectedGroupName = name;
                          });
                          setModal(() {});
                          Navigator.pop(ctx);
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                          decoration: BoxDecoration(
                            color: isSelected ? brightBlue.withOpacity(0.15) : Colors.white.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: isSelected ? brightBlue : Colors.white.withOpacity(0.1),
                              width: isSelected ? 2 : 1,
                            ),
                          ),
                          child: Row(
                            children: [
                              Container(
                                width: 44, height: 44,
                                decoration: BoxDecoration(
                                  color: isSelected ? brightBlue.withOpacity(0.3) : Colors.white.withOpacity(0.08),
                                  shape: BoxShape.circle,
                                ),
                                child: Center(
                                  child: Text(
                                    name.isNotEmpty ? name[0].toUpperCase() : "G",
                                    style: TextStyle(color: isSelected ? Colors.white : Colors.white54, fontWeight: FontWeight.bold, fontSize: 18),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 14),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(name, style: TextStyle(color: isSelected ? Colors.white : Colors.white70, fontWeight: FontWeight.bold, fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis),
                                    const SizedBox(height: 3),
                                    Text("$count anggota", style: TextStyle(color: Colors.white38, fontSize: 11)),
                                  ],
                                ),
                              ),
                              if (isSelected)
                                Container(
                                  width: 28, height: 28,
                                  decoration: BoxDecoration(color: brightBlue, shape: BoxShape.circle),
                                  child: const Icon(Icons.check, color: Colors.white, size: 16),
                                ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _sendGroupBug() async {
    if (_isSending || _baseUrl == null) return;

    // Cek sender pribadi dulu
    final hasSender = await _checkPrivateSender();
    if (!hasSender) {
      // Tidak ada sender pribadi - tidak tampilkan apa-apa
      return;
    }

    // Kalau belum pilih group, fetch dan tampilkan sheet
    if (_selectedGroupJid == null) {
      await _fetchMyGroups();
      _showGroupSelectionSheet();
      return;
    }

    // Sudah ada group terpilih - langsung kirim pakai JID
    setState(() => _isSending = true);
    _buttonController.forward().then((_) => _buttonController.reverse());

    final key = widget.sessionKey;

    try {
      final url = Uri.parse("$_baseUrl/api/whatsapp/groupBug?key=$key&groupJid=${Uri.encodeComponent(_selectedGroupJid!)}");
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data["valid"] == false) {
        _showAlert("❌ Failed", data["message"] ?? "Failed to send group bug.");
      } else {
        _showSuccessPopup(_selectedGroupName ?? _selectedGroupJid!, data);
      }
    } catch (e) {
      _showAlert("❌ Error", "Terjadi kesalahan: ${e.toString()}");
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _showSuccessPopup(String linkGroup, Map<String, dynamic> data) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => GroupBugSuccessDialog(
        linkGroup: linkGroup,
        data: data,
        onDismiss: () {
          Navigator.of(context).pop();
        },
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.95),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
          side: BorderSide(color: brightBlue.withOpacity(0.3), width: 1),
        ),
        title: Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron')),
        content: Text(msg, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: brightBlue)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (!["vip", "owner"].contains(widget.role.toLowerCase())) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(FontAwesomeIcons.lock, color: Colors.red, size: 60),
              const SizedBox(height: 20),
              const Text("ACCESS DENIED", style: TextStyle(color: Colors.red, fontSize: 24, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
              const SizedBox(height: 10),
              Text("This feature is only available for VIP and Owner users",
                  style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 16), textAlign: TextAlign.center),
            ],
          ),
        ),
      );
    }

    const red = Color(0xFFCC1A1A);
    const darkBg = Color(0xFF0D0D0D);

    return Scaffold(
      backgroundColor: darkBg,
      body: SafeArea(
        child: Column(
          children: [
            // ── AppBar ──
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      width: 44, height: 44,
                      decoration: BoxDecoration(color: Colors.white.withOpacity(0.07), borderRadius: BorderRadius.circular(12)),
                      child: const Icon(Icons.arrow_back, color: Colors.white, size: 22),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Container(
                    width: 44, height: 44,
                    decoration: const BoxDecoration(color: red, shape: BoxShape.circle),
                    child: const Icon(Icons.group, color: Colors.white, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Bug Groups", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 17)),
                      Text(
                        _myGroups.isEmpty ? "No sender connected" : "${_myGroups.length} group tersedia",
                        style: TextStyle(color: Colors.white38, fontSize: 11),
                      ),
                    ],
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: () async {
                      final hasSender = await _checkPrivateSender();
                      if (hasSender) {
                        await _fetchMyGroups();
                        setState(() {});
                      }
                    },
                    child: Container(
                      width: 44, height: 44,
                      decoration: BoxDecoration(color: Colors.white.withOpacity(0.07), shape: BoxShape.circle),
                      child: const Icon(Icons.refresh, color: Colors.white70, size: 22),
                    ),
                  ),
                ],
              ),
            ),

            // ── Join New Group card ──
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.08)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 30, height: 30,
                          decoration: const BoxDecoration(color: red, shape: BoxShape.circle),
                          child: const Icon(Icons.add, color: Colors.white, size: 16),
                        ),
                        const SizedBox(width: 10),
                        const Text("Join New Group", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 15)),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.05),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white.withOpacity(0.1)),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.link, color: Colors.white38, size: 18),
                          const SizedBox(width: 10),
                          Expanded(
                            child: TextField(
                              controller: linkGroupController,
                              style: const TextStyle(color: Colors.white, fontSize: 14),
                              cursorColor: red,
                              decoration: InputDecoration(
                                hintText: "Enter group JID or link...",
                                hintStyle: TextStyle(color: Colors.white24, fontSize: 14),
                                border: InputBorder.none,
                                isDense: true,
                                contentPadding: EdgeInsets.zero,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton.icon(
                        onPressed: _isSending ? null : _joinAndBugGroup,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: red,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          elevation: 0,
                        ),
                        icon: _isSending
                            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                            : const Icon(Icons.add, size: 20),
                        label: Text(
                          _isSending ? "JOINING..." : "JOIN GROUP",
                          style: const TextStyle(fontFamily: 'Orbitron', fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 1.5),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),

            // ── Group list ──
            Expanded(
              child: _myGroups.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 100, height: 100,
                            decoration: BoxDecoration(color: Colors.white.withOpacity(0.07), shape: BoxShape.circle),
                            child: const Icon(Icons.group_off, color: Colors.white24, size: 48),
                          ),
                          const SizedBox(height: 20),
                          const Text("No Groups Available", style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w600)),
                          const SizedBox(height: 8),
                          Text(
                            "Connect a WhatsApp sender and join\ngroups to start sending bugs",
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.white38, fontSize: 13, height: 1.5),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: _myGroups.length,
                      itemBuilder: (_, i) {
                        final group = _myGroups[i];
                        final jid = group['jid'] as String;
                        final name = group['name'] as String;
                        final count = group['participants'] ?? 0;
                        final isSelected = _selectedGroupJid == jid;

                        return GestureDetector(
                          onTap: () => setState(() {
                            _selectedGroupJid = jid;
                            _selectedGroupName = name;
                          }),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            margin: const EdgeInsets.only(bottom: 10),
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                            decoration: BoxDecoration(
                              color: isSelected ? red.withOpacity(0.15) : Colors.white.withOpacity(0.05),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: isSelected ? red : Colors.white.withOpacity(0.08),
                                width: isSelected ? 2 : 1,
                              ),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 44, height: 44,
                                  decoration: BoxDecoration(
                                    color: isSelected ? red : Colors.white.withOpacity(0.08),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Center(
                                    child: Text(
                                      name.isNotEmpty ? name[0].toUpperCase() : "G",
                                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis),
                                      const SizedBox(height: 3),
                                      Text("$count anggota", style: TextStyle(color: Colors.white38, fontSize: 11)),
                                    ],
                                  ),
                                ),
                                if (isSelected)
                                  GestureDetector(
                                    onTap: _sendGroupBug,
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                                      decoration: BoxDecoration(
                                        color: red,
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: const Text("BUG", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'Orbitron')),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),

            // Footer
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text("◦  TEXAS SYSTEM v2.0  ◦",
                  style: TextStyle(color: Colors.white.withOpacity(0.15), fontSize: 11, letterSpacing: 2, fontFamily: 'ShareTechMono')),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _joinAndBugGroup() async {
    if (_isSending || _baseUrl == null) return;
    final hasSender = await _checkPrivateSender();
    if (!hasSender) return;

    final input = linkGroupController.text.trim();
    if (input.isEmpty) return;

    setState(() => _isSending = true);
    try {
      final url = Uri.parse("$_baseUrl/api/whatsapp/groupBug?key=${widget.sessionKey}&linkGroup=${Uri.encodeComponent(input)}");
      final res = await http.get(url).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data["valid"] == false) {
        _showAlert("❌ Failed", data["message"] ?? "Gagal.");
      } else {
        linkGroupController.clear();
        _showSuccessPopup(input, data);
        await _fetchMyGroups();
        setState(() {});
      }
    } catch (e) {
      _showAlert("❌ Error", e.toString());
    } finally {
      setState(() => _isSending = false);
    }
  }


  @override
  void dispose() {
    _buttonController.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    _glowController.dispose();
    _videoController.dispose();
    linkGroupController.dispose();
    super.dispose();
  }
}

class GroupBugSuccessDialog extends StatefulWidget {
  final String linkGroup;
  final Map<String, dynamic> data;
  final VoidCallback onDismiss;

  const GroupBugSuccessDialog({
    super.key,
    required this.linkGroup,
    required this.data,
    required this.onDismiss,
  });

  @override
  State<GroupBugSuccessDialog> createState() => _GroupBugSuccessDialogState();
}

class _GroupBugSuccessDialogState extends State<GroupBugSuccessDialog> with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _scaleController;
  late AnimationController _glowController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _glowAnimation;
  bool _showDetails = false;

  final Color brightBlue = const Color(0xFF9E9E9E);
  final Color deepBlue = const Color(0xFF0D47A1);

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _scaleController = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _glowController = AnimationController(vsync: this, duration: const Duration(milliseconds: 2000))..repeat(reverse: true);
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _fadeController, curve: Curves.easeIn));
    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut));
    _glowAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(CurvedAnimation(parent: _glowController, curve: Curves.easeInOut));

    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) {
        setState(() => _showDetails = true);
        _fadeController.forward();
        _scaleController.forward();
      }
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _scaleController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.zero,
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: screenSize.width * 0.9, maxHeight: screenSize.height * 0.55),
        child: Container(
          width: screenSize.width * 0.9,
          height: screenSize.height * 0.55,
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.95),
            borderRadius: BorderRadius.circular(28), // Dialog sangat tumpul
            border: Border.all(color: brightBlue.withOpacity(0.3), width: 1),
            boxShadow: [BoxShadow(color: brightBlue.withOpacity(0.1), blurRadius: 15, spreadRadius: 3)],
          ),
          child: Stack(
            children: [
              Positioned(
                top: 20,
                left: 0,
                right: 0,
                child: Column(
                  children: [
                    AnimatedBuilder(
                      animation: _glowController,
                      builder: (context, child) {
                        return Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: brightBlue.withOpacity(0.1 + 0.1 * _glowAnimation.value),
                            borderRadius: BorderRadius.circular(100),
                            border: Border.all(color: brightBlue.withOpacity(0.3 + 0.2 * _glowAnimation.value), width: 2),
                            boxShadow: [BoxShadow(color: brightBlue.withOpacity(0.2 * _glowAnimation.value), blurRadius: 15, spreadRadius: 3)],
                          ),
                          child: Icon(FontAwesomeIcons.checkDouble, color: brightBlue, size: 40),
                        );
                      },
                    ),
                    const SizedBox(height: 16),
                    Text(
                      "GROUP BUG SENT!",
                      style: TextStyle(color: brightBlue, fontSize: 20, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 2),
                    ),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
              if (_showDetails)
                Positioned(
                  top: 100,
                  left: 20,
                  right: 20,
                  bottom: 80,
                  child: FadeTransition(
                    opacity: _fadeAnimation,
                    child: ScaleTransition(
                      scale: _scaleAnimation,
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(22), // Detail box tumpul
                          border: Border.all(color: brightBlue.withOpacity(0.2)),
                        ),
                        child: SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text("Attack Details:", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                              const SizedBox(height: 12),
                              _buildDetailRow("Group Link", widget.linkGroup),
                              _buildDetailRow("Success", widget.data["success"] == true ? "Yes" : "No"),
                              if (widget.data["canSendMessage"] != null)
                                _buildDetailRow("Can Send Msg", widget.data["canSendMessage"] == true ? "Yes" : "No"),
                              if (widget.data["groupInfo"] != null) ...[
                                _buildDetailRow("Group Name", widget.data["groupInfo"]["subject"] ?? "Unknown"),
                                _buildDetailRow("Members", widget.data["groupInfo"]["participants"]?.toString() ?? "Unknown"),
                                _buildDetailRow("Description", widget.data["groupInfo"]["desc"] ?? "No description"),
                              ],
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              Positioned(
                bottom: 20,
                left: 20,
                right: 20,
                child: ElevatedButton(
                  onPressed: widget.onDismiss,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: brightBlue.withOpacity(0.1),
                    foregroundColor: brightBlue,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30), // Tombol Done tumpul
                      side: BorderSide(color: brightBlue.withOpacity(0.3)),
                    ),
                  ),
                  child: Text("DONE", style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, fontFamily: 'Orbitron', letterSpacing: 1, color: brightBlue)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text("$label:", style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 12, fontFamily: 'ShareTechMono')),
          ),
          Expanded(
            child: Text(value, style: TextStyle(color: brightBlue, fontSize: 12, fontFamily: 'ShareTechMono')),
          ),
        ],
      ),
    );
  }
}