import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MantaMusicPage extends StatefulWidget {
  final String sessionKey;
  const MantaMusicPage({super.key, required this.sessionKey});

  @override
  State<MantaMusicPage> createState() => _MantaMusicPageState();
}

class _MantaMusicPageState extends State<MantaMusicPage>
    with TickerProviderStateMixin {
  // ── Colors ──
  static const Color primary = Color(0xFF1DB954);
  static const Color bg = Color(0xFF0A0A0A);
  static const Color surface = Color(0xFF1A1A1A);
  static const Color surface2 = Color(0xFF232323);

  // ── Tab ──
  int _tab = 0; // 0=search, 1=playlist, 2=favorites, 3=downloads
  final List<String> _tabLabels = ['Search', 'Playlist', 'Favorites', 'Downloads'];
  final List<IconData> _tabIcons = [
    Icons.search,
    Icons.queue_music,
    Icons.favorite_border,
    Icons.download_outlined,
  ];

  // ── Search ──
  final TextEditingController _searchCtrl = TextEditingController();
  List<Map<String, dynamic>> _results = [];
  bool _searching = false;
  Timer? _debounce;

  // ── Player ──
  final AudioPlayer _player = AudioPlayer();
  Map<String, dynamic>? _currentSong;
  bool _isPlaying = false;
  bool _shuffle = false;
  bool _repeat = false;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  late AnimationController _rotateCtrl;

  // ── Favorites & Playlist ──
  List<Map<String, dynamic>> _favorites = [];
  List<Map<String, dynamic>> _playlist = [];

  @override
  void initState() {
    super.initState();
    _rotateCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 10));
    _player.playerStateStream.listen((state) {
      if (mounted) {
        setState(() => _isPlaying = state.playing);
        if (state.playing) _rotateCtrl.repeat();
        else _rotateCtrl.stop();
      }
    });
    _player.positionStream.listen((pos) { if (mounted) setState(() => _position = pos); });
    _player.durationStream.listen((dur) { if (mounted) setState(() => _duration = dur ?? Duration.zero); });
    _player.processingStateStream.listen((state) { if (state == ProcessingState.completed) _nextSong(); });
    _loadFavorites();
    _loadRandomMusic();
  }

  // ── Helper: extract list from various response formats ──
  List<dynamic> _extractList(dynamic data) {
    if (data is List) return data;
    if (data is Map) {
      for (final key in ['results', 'result', 'data', 'tracks', 'items', 'songs']) {
        if (data[key] is List) return data[key];
      }
    }
    return [];
  }

  Map<String, dynamic> _parseTrack(dynamic s) {
    final title = s['title'] ?? s['name'] ?? s['song'] ?? 'Unknown';
    final artist = s['artist'] ?? s['artists'] ?? s['singer'] ?? '';
    final image = s['image'] ?? s['thumbnail'] ?? s['cover'] ?? s['img'] ?? '';
    final downloadKey = s['download'] ?? s['id'] ?? s['key'] ?? s['url'] ?? '';
    return {
      'id': (s['id'] ?? title.toString().hashCode).toString(),
      'title': title.toString(),
      'artist': artist is List ? (artist as List).join(', ') : artist.toString(),
      'image': image.toString(),
      'downloadKey': downloadKey.toString(),
      'url': '',
      'duration': s['duration'] ?? 0,
    };
  }

  // ── Fetch download URL via own API ──
  Future<String> _fetchDownloadUrl(String key) async {
    try {
      final uri = Uri.parse('https://aliicia.my.id/api/music?download=${Uri.encodeComponent(key)}');
      final res = await http.get(uri).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final inner = data is Map ? (data['data'] ?? data) : data;
        return (inner['url'] ?? inner['download'] ?? inner['link'] ?? inner['audio'] ?? inner['stream'] ?? '').toString();
      }
    } catch (_) {}
    return '';
  }

  // ── Load random music ──
  Future<void> _loadRandomMusic() async {
    setState(() => _searching = true);
    try {
      final uri = Uri.parse('https://aliicia.my.id/api/music?alicia=random');
      final res = await http.get(uri).timeout(const Duration(seconds: 12));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final raw = _extractList(data);
        if (raw.isNotEmpty && mounted) {
          setState(() => _results = raw.map<Map<String, dynamic>>((s) => _parseTrack(s)).toList());
        }
      }
    } catch (_) {}
    if (mounted) setState(() => _searching = false);
  }

  @override
  void dispose() {
    _player.dispose();
    _rotateCtrl.dispose();
    _searchCtrl.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  Future<void> _search(String q) async {
    if (q.trim().isEmpty) { setState(() => _results = []); return; }
    setState(() { _searching = true; _results = []; });
    try {
      final uri = Uri.parse('https://aliicia.my.id/api/music?query=${Uri.encodeComponent(q)}');
      final res = await http.get(uri).timeout(const Duration(seconds: 12));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final raw = _extractList(data);
        setState(() => _results = raw.map<Map<String, dynamic>>((s) => _parseTrack(s)).toList());
        if (_results.isEmpty) _showSnack('Lagu tidak ditemukan');
      } else {
        _showSnack('Gagal: HTTP ${res.statusCode}');
      }
    } catch (e) {
      _showSnack('Gagal terhubung');
    }
    setState(() => _searching = false);
  }

  Future<void> _playSong(Map<String, dynamic> song) async {
    try {
      await _player.stop();
      setState(() => _currentSong = song);

      // Ambil url mentah dulu jika belum ada
      String audioUrl = song['url'] as String? ?? '';
      if (audioUrl.isEmpty) {
        final key = song['downloadKey'] as String? ?? '';
        if (key.isEmpty) { _showSnack('Link lagu tidak tersedia'); return; }
        _showSnack('Mengambil link lagu...');
        audioUrl = await _fetchDownloadUrl(key);
        // Cache url ke song
        song['url'] = audioUrl;
      }

      if (audioUrl.isEmpty) { _showSnack('Lagu tidak tersedia'); return; }

      await _player.setUrl(audioUrl);
      await _player.play();

      if (!_playlist.any((s) => s['id'] == song['id'])) {
        setState(() => _playlist.add(song));
      }
    } catch (e) {
      _showSnack('Gagal memutar lagu');
    }
  }

  void _nextSong() {
    if (_playlist.isEmpty || _currentSong == null) return;
    final idx = _playlist.indexWhere((s) => s['id'] == _currentSong!['id']);
    if (_shuffle) {
      final next = _playlist[(_playlist.length * (DateTime.now().millisecond / 1000)).floor() % _playlist.length];
      _playSong(next);
    } else if (idx < _playlist.length - 1) {
      _playSong(_playlist[idx + 1]);
    } else if (_repeat) {
      _playSong(_playlist[0]);
    }
  }

  void _prevSong() {
    if (_playlist.isEmpty || _currentSong == null) return;
    final idx = _playlist.indexWhere((s) => s['id'] == _currentSong!['id']);
    if (idx > 0) _playSong(_playlist[idx - 1]);
  }

  void _toggleFavorite(Map<String, dynamic> song) {
    setState(() {
      if (_favorites.any((s) => s['id'] == song['id'])) {
        _favorites.removeWhere((s) => s['id'] == song['id']);
      } else {
        _favorites.add(song);
      }
    });
    _saveFavorites();
  }

  bool _isFav(String id) => _favorites.any((s) => s['id'] == id);

  Future<void> _loadFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('manta_music_favs') ?? '[]';
    final list = jsonDecode(raw) as List;
    setState(() => _favorites = list.cast<Map<String, dynamic>>());
  }

  Future<void> _saveFavorites() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('manta_music_favs', jsonEncode(_favorites));
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), backgroundColor: surface2, duration: const Duration(seconds: 2)),
    );
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  // ═══════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg,
      body: Column(
        children: [
          _buildAppBar(),
          _buildSearchBar(),
          _buildTabs(),
          Expanded(child: _buildTabContent()),
          if (_currentSong != null) _buildMiniPlayer(),
        ],
      ),
    );
  }

  // ── App Bar ──
  Widget _buildAppBar() {
    return SafeArea(
      bottom: false,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: const Icon(Icons.arrow_back, color: Colors.white, size: 22),
            ),
            const SizedBox(width: 12),
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: primary,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(Icons.music_note_rounded, color: Colors.white, size: 20),
            ),
            const SizedBox(width: 10),
            const Text(
              'TEXAS Music',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                letterSpacing: 0.5,
              ),
            ),
            const Spacer(),
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.history, color: Colors.white54, size: 18),
            ),
            const SizedBox(width: 8),
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.queue_music, color: Colors.white54, size: 18),
            ),
          ],
        ),
      ),
    );
  }

  // ── Search Bar ──
  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Container(
        height: 48,
        decoration: BoxDecoration(
          color: surface,
          borderRadius: BorderRadius.circular(28),
        ),
        child: TextField(
          controller: _searchCtrl,
          style: const TextStyle(color: Colors.white, fontSize: 14),
          onChanged: (q) {
            _debounce?.cancel();
            _debounce = Timer(const Duration(milliseconds: 500), () => _search(q));
            if (_tab != 0) setState(() => _tab = 0);
          },
          decoration: InputDecoration(
            hintText: 'Search songs, artists...',
            hintStyle: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 14),
            prefixIcon: Icon(Icons.search, color: Colors.white.withOpacity(0.4), size: 20),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(vertical: 14),
          ),
        ),
      ),
    );
  }

  // ── Tab Bar ──
  Widget _buildTabs() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: List.generate(_tabLabels.length, (i) {
          final active = _tab == i;
          return GestureDetector(
            onTap: () => setState(() => _tab = i),
            child: Column(
              children: [
                Icon(_tabIcons[i],
                    color: active ? primary : Colors.white38, size: 22),
                const SizedBox(height: 4),
                Text(
                  _tabLabels[i],
                  style: TextStyle(
                    color: active ? primary : Colors.white38,
                    fontSize: 11,
                    fontWeight: active ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
                const SizedBox(height: 4),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  height: 2,
                  width: active ? 28 : 0,
                  decoration: BoxDecoration(
                    color: primary,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }

  // ── Tab Content ──
  Widget _buildTabContent() {
    switch (_tab) {
      case 0: return _buildSearchTab();
      case 1: return _buildListTab(_playlist, emptyMsg: 'Belum ada lagu di playlist');
      case 2: return _buildListTab(_favorites, emptyMsg: 'Belum ada favorit');
      case 3: return _buildEmptyState('Download belum tersedia');
      default: return const SizedBox();
    }
  }

  Widget _buildSearchTab() {
    if (_searching) {
      return const Center(child: CircularProgressIndicator(color: primary));
    }
    if (_results.isEmpty && _searchCtrl.text.isNotEmpty) {
      return _buildEmptyState('Lagu tidak ditemukan');
    }
    if (_results.isEmpty) {
      return _buildEmptyState('Ketik nama lagu atau artis');
    }
    return _buildListTab(_results, emptyMsg: '');
  }

  Widget _buildListTab(List<Map<String, dynamic>> songs, {required String emptyMsg}) {
    if (songs.isEmpty) return _buildEmptyState(emptyMsg);
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      itemCount: songs.length,
      itemBuilder: (_, i) => _buildSongTile(songs[i]),
    );
  }

  Widget _buildSongTile(Map<String, dynamic> song) {
    final isActive = _currentSong?['id'] == song['id'];
    final fav = _isFav(song['id'] ?? '');
    return GestureDetector(
      onTap: () => _playSong(song),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: isActive ? primary.withOpacity(0.15) : surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isActive ? primary.withOpacity(0.5) : Colors.transparent,
            width: 1,
          ),
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: song['image'] != null && (song['image'] as String).isNotEmpty
                  ? Image.network(song['image'], width: 50, height: 50, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _songPlaceholder())
                  : _songPlaceholder(),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    song['title'] ?? '',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: isActive ? primary : Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    song['artist'] ?? '',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 11),
                  ),
                ],
              ),
            ),
            GestureDetector(
              onTap: () => _toggleFavorite(song),
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Icon(
                  fav ? Icons.favorite : Icons.favorite_border,
                  color: fav ? primary : Colors.white38,
                  size: 18,
                ),
              ),
            ),
            if (isActive && _isPlaying)
              const SizedBox(
                width: 18, height: 18,
                child: CircularProgressIndicator(color: primary, strokeWidth: 2),
              ),
          ],
        ),
      ),
    );
  }

  Widget _songPlaceholder() {
    return Container(
      width: 50, height: 50,
      color: surface2,
      child: const Icon(Icons.music_note, color: primary, size: 22),
    );
  }

  Widget _buildEmptyState(String msg) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.music_off_outlined, color: Colors.white12, size: 64),
          const SizedBox(height: 12),
          Text(msg, style: const TextStyle(color: Colors.white24, fontSize: 14)),
        ],
      ),
    );
  }

  // ── Mini Player ──
  Widget _buildMiniPlayer() {
    final song = _currentSong!;
    return GestureDetector(
      onTap: () => _showFullPlayer(),
      child: Container(
        color: bg,
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Progress bar
            SliderTheme(
              data: SliderThemeData(
                trackHeight: 2,
                thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 5),
                overlayShape: const RoundSliderOverlayShape(overlayRadius: 10),
                activeTrackColor: primary,
                inactiveTrackColor: surface2,
                thumbColor: primary,
                overlayColor: primary.withOpacity(0.2),
              ),
              child: Slider(
                value: _duration.inSeconds > 0
                    ? _position.inSeconds.toDouble().clamp(0, _duration.inSeconds.toDouble())
                    : 0,
                max: _duration.inSeconds > 0 ? _duration.inSeconds.toDouble() : 1,
                onChanged: (v) => _player.seek(Duration(seconds: v.toInt())),
              ),
            ),
            Row(
              children: [
                Text(_fmt(_position), style: const TextStyle(color: Colors.white38, fontSize: 10)),
                const Spacer(),
                Text(_fmt(_duration), style: const TextStyle(color: Colors.white38, fontSize: 10)),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                // Album art rotating
                RotationTransition(
                  turns: _rotateCtrl,
                  child: ClipOval(
                    child: song['image'] != null && (song['image'] as String).isNotEmpty
                        ? Image.network(song['image'], width: 44, height: 44, fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(width: 44, height: 44, color: surface2,
                                child: const Icon(Icons.music_note, color: primary, size: 20)))
                        : Container(width: 44, height: 44, color: surface2,
                            child: const Icon(Icons.music_note, color: primary, size: 20)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(song['title'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                      Text(song['artist'] ?? '', maxLines: 1,
                          style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 11)),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => _toggleFavorite(song),
                  icon: Icon(_isFav(song['id'] ?? '') ? Icons.favorite : Icons.favorite_border,
                      color: _isFav(song['id'] ?? '') ? primary : Colors.white38, size: 20),
                ),
                // Controls
                IconButton(onPressed: _prevSong, icon: const Icon(Icons.skip_previous_rounded, color: Colors.white, size: 28)),
                GestureDetector(
                  onTap: () => _isPlaying ? _player.pause() : _player.play(),
                  child: Container(
                    width: 48, height: 48,
                    decoration: const BoxDecoration(color: primary, shape: BoxShape.circle),
                    child: Icon(_isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                        color: Colors.white, size: 26),
                  ),
                ),
                IconButton(onPressed: _nextSong, icon: const Icon(Icons.skip_next_rounded, color: Colors.white, size: 28)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ── Full Player Bottom Sheet ──
  void _showFullPlayer() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setBS) {
          return StreamBuilder<Duration>(
            stream: _player.positionStream,
            builder: (_, snap) {
              final pos = snap.data ?? _position;
              return Container(
                height: MediaQuery.of(context).size.height * 0.85,
                decoration: const BoxDecoration(
                  color: Color(0xFF111111),
                  borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
                ),
                child: Column(
                  children: [
                    const SizedBox(height: 12),
                    Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2))),
                    const SizedBox(height: 24),
                    // Rotating album art
                    RotationTransition(
                      turns: _rotateCtrl,
                      child: ClipOval(
                        child: _currentSong!['image'] != null
                            ? Image.network(_currentSong!['image'], width: 220, height: 220, fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(width: 220, height: 220, color: surface2,
                                    child: const Icon(Icons.music_note, color: primary, size: 80)))
                            : Container(width: 220, height: 220, color: surface2,
                                child: const Icon(Icons.music_note, color: primary, size: 80)),
                      ),
                    ),
                    const SizedBox(height: 24),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 28),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(_currentSong!['title'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                                const SizedBox(height: 4),
                                Text(_currentSong!['artist'] ?? '',
                                    style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 13)),
                              ],
                            ),
                          ),
                          GestureDetector(
                            onTap: () { _toggleFavorite(_currentSong!); setBS(() {}); },
                            child: Icon(
                              _isFav(_currentSong!['id'] ?? '') ? Icons.favorite : Icons.favorite_border,
                              color: _isFav(_currentSong!['id'] ?? '') ? primary : Colors.white38, size: 26),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    // Progress
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: SliderTheme(
                        data: SliderThemeData(
                          trackHeight: 3,
                          thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7),
                          activeTrackColor: primary,
                          inactiveTrackColor: surface2,
                          thumbColor: Colors.white,
                          overlayColor: primary.withOpacity(0.2),
                        ),
                        child: Slider(
                          value: _duration.inSeconds > 0
                              ? pos.inSeconds.toDouble().clamp(0, _duration.inSeconds.toDouble())
                              : 0,
                          max: _duration.inSeconds > 0 ? _duration.inSeconds.toDouble() : 1,
                          onChanged: (v) => _player.seek(Duration(seconds: v.toInt())),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 28),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(_fmt(pos), style: const TextStyle(color: Colors.white38, fontSize: 11)),
                          Text(_fmt(_duration), style: const TextStyle(color: Colors.white38, fontSize: 11)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    // Controls
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        IconButton(
                          onPressed: () { setState(() => _shuffle = !_shuffle); setBS(() {}); },
                          icon: Icon(Icons.shuffle, color: _shuffle ? primary : Colors.white38, size: 24),
                        ),
                        IconButton(onPressed: _prevSong, icon: const Icon(Icons.skip_previous_rounded, color: Colors.white, size: 36)),
                        GestureDetector(
                          onTap: () { _isPlaying ? _player.pause() : _player.play(); setBS(() {}); },
                          child: Container(
                            width: 64, height: 64,
                            decoration: const BoxDecoration(color: primary, shape: BoxShape.circle),
                            child: Icon(_isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                                color: Colors.white, size: 36),
                          ),
                        ),
                        IconButton(onPressed: _nextSong, icon: const Icon(Icons.skip_next_rounded, color: Colors.white, size: 36)),
                        IconButton(
                          onPressed: () { setState(() => _repeat = !_repeat); setBS(() {}); },
                          icon: Icon(Icons.repeat, color: _repeat ? primary : Colors.white38, size: 24),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
